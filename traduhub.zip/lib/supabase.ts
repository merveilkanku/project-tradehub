import { createClient } from "@supabase/supabase-js"

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!

console.log("[v0] Supabase URL:", supabaseUrl ? "✓ Définie" : "✗ Manquante")
console.log("[v0] Supabase Key:", supabaseAnonKey ? "✓ Définie" : "✗ Manquante")

if (!supabaseUrl || !supabaseAnonKey) {
  console.error("[v0] Variables d'environnement Supabase manquantes")
  throw new Error("Variables d'environnement Supabase manquantes")
}

export const supabase = createClient(supabaseUrl, supabaseAnonKey, {
  auth: {
    autoRefreshToken: true,
    persistSession: true,
    detectSessionInUrl: true,
    flowType: "pkce",
  },
  global: {
    headers: {
      "X-Client-Info": "traduhub-web",
    },
    fetch: (url, options = {}) => {
      console.log("[v0] Supabase fetch:", url)
      return fetch(url, options).catch((error) => {
        console.error("[v0] Supabase fetch error:", error)
        console.error("[v0] Error details:", {
          message: error.message,
          name: error.name,
          stack: error.stack,
        })
        throw error
      })
    },
  },
})

export type Database = {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          user_type: "simple" | "supplier"
          email: string
          phone: string
          username: string
          full_name: string
          bio: string | null
          avatar_url: string | null
          country: string
          city: string
          address: string
          is_verified: boolean
          payment_status: "pending" | "paid" | "free"
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          user_type: "simple" | "supplier"
          email: string
          phone: string
          username: string
          full_name: string
          bio?: string | null
          avatar_url?: string | null
          country: string
          city: string
          address: string
          is_verified?: boolean
          payment_status?: "pending" | "paid" | "free"
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_type?: "simple" | "supplier"
          email?: string
          phone?: string
          username?: string
          full_name?: string
          bio?: string | null
          avatar_url?: string | null
          country?: string
          city?: string
          address?: string
          is_verified?: boolean
          payment_status?: "pending" | "paid" | "free"
          created_at?: string
          updated_at?: string
        }
      }
      products: {
        Row: {
          id: string
          supplier_id: string
          title: string
          description: string
          price: number
          currency: string
          category: string
          images: string[]
          stock_quantity: number
          is_active: boolean
          country: string
          city: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          supplier_id: string
          title: string
          description: string
          price: number
          currency?: string
          category: string
          images?: string[]
          stock_quantity?: number
          is_active?: boolean
          country: string
          city: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          supplier_id?: string
          title?: string
          description?: string
          price?: number
          currency?: string
          category?: string
          images?: string[]
          stock_quantity?: number
          is_active?: boolean
          country?: string
          city?: string
          created_at?: string
          updated_at?: string
        }
      }
      categories: {
        Row: {
          id: string
          name: string
          slug: string
          description: string | null
          icon: string | null
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          slug: string
          description?: string | null
          icon?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          slug?: string
          description?: string | null
          icon?: string | null
          created_at?: string
        }
      }
      conversations: {
        Row: {
          id: string
          buyer_id: string
          supplier_id: string
          product_id: string | null
          last_message: string | null
          last_message_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          buyer_id: string
          supplier_id: string
          product_id?: string | null
          last_message?: string | null
          last_message_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          buyer_id?: string
          supplier_id?: string
          product_id?: string | null
          last_message?: string | null
          last_message_at?: string | null
          created_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          conversation_id: string
          sender_id: string
          content: string
          message_type: "text" | "image" | "file"
          file_url: string | null
          is_read: boolean
          created_at: string
        }
        Insert: {
          id?: string
          conversation_id: string
          sender_id: string
          content: string
          message_type?: "text" | "image" | "file"
          file_url?: string | null
          is_read?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          conversation_id?: string
          sender_id?: string
          content?: string
          message_type?: "text" | "image" | "file"
          file_url?: string | null
          is_read?: boolean
          created_at?: string
        }
      }
      product_likes: {
        Row: {
          id: string
          user_id: string
          product_id: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          product_id: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          product_id?: string
          created_at?: string
        }
      }
      product_comments: {
        Row: {
          id: string
          user_id: string
          product_id: string
          content: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          product_id: string
          content: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          product_id?: string
          content?: string
          created_at?: string
        }
      }
      orders: {
        Row: {
          id: string
          buyer_id: string
          supplier_id: string
          product_id: string
          quantity: number
          total_price: number
          status: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
          shipping_address: string
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          buyer_id: string
          supplier_id: string
          product_id: string
          quantity: number
          total_price: number
          status?: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
          shipping_address: string
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          buyer_id?: string
          supplier_id?: string
          product_id?: string
          quantity?: number
          total_price?: number
          status?: "pending" | "confirmed" | "shipped" | "delivered" | "cancelled"
          shipping_address?: string
          created_at?: string
          updated_at?: string
        }
      }
    }
  }
}
