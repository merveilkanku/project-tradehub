import { supabase } from "./supabase"
import type { Database } from "./supabase"

export type UserProfile = Database["public"]["Tables"]["profiles"]["Row"]
export type UserType = "simple" | "supplier"

export interface AuthUser {
  id: string
  email: string
  profile: UserProfile | null
}

let isDemoMode = false

// Check if Supabase is working
const checkSupabaseConnection = async (): Promise<boolean> => {
  try {
    await supabase.from("profiles").select("id").limit(1)
    return true
  } catch (error) {
    console.log("[v0] Supabase not available, switching to demo mode")
    isDemoMode = true
    return false
  }
}

// Demo mode storage helpers
const DEMO_USERS_KEY = "tradehub_demo_users"
const DEMO_CURRENT_USER_KEY = "tradehub_demo_current_user"

const getDemoUsers = (): any[] => {
  if (typeof window === "undefined") return []
  const users = localStorage.getItem(DEMO_USERS_KEY)
  return users ? JSON.parse(users) : []
}

const saveDemoUsers = (users: any[]) => {
  if (typeof window === "undefined") return
  localStorage.setItem(DEMO_USERS_KEY, JSON.stringify(users))
}

const getCurrentDemoUser = (): AuthUser | null => {
  if (typeof window === "undefined") return null
  const user = localStorage.getItem(DEMO_CURRENT_USER_KEY)
  return user ? JSON.parse(user) : null
}

const setCurrentDemoUser = (user: AuthUser | null) => {
  if (typeof window === "undefined") return
  if (user) {
    localStorage.setItem(DEMO_CURRENT_USER_KEY, JSON.stringify(user))
  } else {
    localStorage.removeItem(DEMO_CURRENT_USER_KEY)
  }
}

export class AuthService {
  static async signUp(data: {
    email: string
    password: string
    phone: string
    username: string
    fullName: string
    userType: UserType
    country: string
    city: string
    address: string
  }) {
    try {
      // Check if Supabase is available
      const supabaseAvailable = await checkSupabaseConnection()

      if (!supabaseAvailable) {
        // Demo mode signup
        const demoUsers = getDemoUsers()

        // Check for existing email/username/phone
        const existingUser = demoUsers.find(
          (u) => u.email === data.email || u.username === data.username || u.phone === data.phone,
        )

        if (existingUser) {
          if (existingUser.email === data.email) {
            throw new Error("Cette adresse email est déjà utilisée")
          }
          if (existingUser.username === data.username) {
            throw new Error("Ce nom d'utilisateur est déjà pris")
          }
          if (existingUser.phone === data.phone) {
            throw new Error("Ce numéro de téléphone est déjà utilisé")
          }
        }

        // Create demo user
        const userId = `demo_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`
        const profileData = {
          id: userId,
          email: data.email,
          phone: data.phone,
          username: data.username,
          full_name: data.fullName,
          user_type: data.userType,
          country: data.country,
          city: data.city,
          address: data.address,
          payment_status: data.userType === "simple" ? "free" : "pending",
          avatar_url: `/placeholder.svg?height=100&width=100&query=avatar+${data.username}`,
          created_at: new Date().toISOString(),
          updated_at: new Date().toISOString(),
        }

        // Save to demo storage
        demoUsers.push({ ...profileData, password: data.password })
        saveDemoUsers(demoUsers)

        // Set as current user
        const authUser: AuthUser = {
          id: userId,
          email: data.email,
          profile: profileData as UserProfile,
        }
        setCurrentDemoUser(authUser)

        return { user: { id: userId, email: data.email }, profile: profileData }
      }

      // Check if email already exists
      const { data: existingUser } = await supabase.from("profiles").select("id").eq("email", data.email).single()

      if (existingUser) {
        throw new Error("Cette adresse email est déjà utilisée")
      }

      // Check if username already exists
      const { data: existingUsername } = await supabase
        .from("profiles")
        .select("id")
        .eq("username", data.username)
        .single()

      if (existingUsername) {
        throw new Error("Ce nom d'utilisateur est déjà pris")
      }

      // Check if phone already exists
      const { data: existingPhone } = await supabase.from("profiles").select("id").eq("phone", data.phone).single()

      if (existingPhone) {
        throw new Error("Ce numéro de téléphone est déjà utilisé")
      }

      // First create the auth user
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: data.email,
        password: data.password,
        options: {
          emailRedirectTo: process.env.NEXT_PUBLIC_DEV_SUPABASE_REDIRECT_URL || window.location.origin,
        },
      })

      if (authError) {
        if (authError.message.includes("User already registered")) {
          throw new Error("Cette adresse email est déjà utilisée")
        }
        if (authError.message.includes("Password should be at least")) {
          throw new Error("Le mot de passe doit contenir au moins 6 caractères")
        }
        if (authError.message.includes("Invalid email")) {
          throw new Error("Adresse email invalide")
        }
        throw new Error(authError.message)
      }

      if (!authData.user) throw new Error("Erreur lors de la création du compte")

      // Then create the profile
      const profileData = {
        id: authData.user.id,
        email: data.email,
        phone: data.phone,
        username: data.username,
        full_name: data.fullName,
        user_type: data.userType,
        country: data.country,
        city: data.city,
        address: data.address,
        payment_status: data.userType === "simple" ? ("free" as const) : ("pending" as const),
        avatar_url: `/placeholder.svg?height=100&width=100&query=avatar+${data.username}`,
      }

      const { error: profileError } = await supabase.from("profiles").insert(profileData)

      if (profileError) {
        // Clean up auth user if profile creation fails
        await supabase.auth.admin.deleteUser(authData.user.id)
        throw new Error("Erreur lors de la création du profil")
      }

      return { user: authData.user, profile: profileData }
    } catch (error: any) {
      throw new Error(error.message || "Erreur lors de l'inscription")
    }
  }

  static async signIn(identifier: string, password: string) {
    try {
      // Check if Supabase is available
      const supabaseAvailable = await checkSupabaseConnection()

      if (!supabaseAvailable) {
        // Demo mode signin
        const demoUsers = getDemoUsers()
        const user = demoUsers.find(
          (u) => u.email === identifier || u.phone === identifier || u.username === identifier,
        )

        if (!user || user.password !== password) {
          throw new Error("Email/téléphone/nom d'utilisateur ou mot de passe incorrect")
        }

        // Set as current user
        const authUser: AuthUser = {
          id: user.id,
          email: user.email,
          profile: user as UserProfile,
        }
        setCurrentDemoUser(authUser)

        return { user: { id: user.id, email: user.email } }
      }

      // Try to sign in with email first
      let { data, error } = await supabase.auth.signInWithPassword({
        email: identifier,
        password,
      })

      // If email fails, try to find user by phone or username
      if (error && error.message.includes("Invalid login credentials")) {
        const { data: profileData } = await supabase
          .from("profiles")
          .select("email")
          .or(`phone.eq.${identifier},username.eq.${identifier}`)
          .single()

        if (profileData) {
          const { data: retryData, error: retryError } = await supabase.auth.signInWithPassword({
            email: profileData.email,
            password,
          })
          data = retryData
          error = retryError
        }
      }

      if (error) {
        if (error.message.includes("Invalid login credentials")) {
          throw new Error("Email/téléphone/nom d'utilisateur ou mot de passe incorrect")
        }
        throw new Error(error.message)
      }
      return data
    } catch (error: any) {
      throw new Error(error.message || "Erreur lors de la connexion")
    }
  }

  static async signOut() {
    try {
      if (isDemoMode || getCurrentDemoUser()) {
        setCurrentDemoUser(null)
        isDemoMode = false
        return
      }

      const { error } = await supabase.auth.signOut()
      if (error) throw error
    } catch (error: any) {
      // Even if Supabase fails, clear demo user
      setCurrentDemoUser(null)
      isDemoMode = false
    }
  }

  static async getCurrentUser(): Promise<AuthUser | null> {
    try {
      // Check demo mode first
      const demoUser = getCurrentDemoUser()
      if (demoUser) {
        isDemoMode = true
        return demoUser
      }

      // Try Supabase
      const {
        data: { user },
      } = await supabase.auth.getUser()
      if (!user) return null

      const { data: profile } = await supabase.from("profiles").select("*").eq("id", user.id).single()

      return {
        id: user.id,
        email: user.email!,
        profile,
      }
    } catch (error) {
      // Return demo user if available
      return getCurrentDemoUser()
    }
  }

  static async updateProfile(userId: string, updates: Partial<UserProfile>) {
    try {
      const demoUser = getCurrentDemoUser()
      if (isDemoMode || demoUser) {
        // Update demo user in localStorage
        const demoUsers = getDemoUsers()
        const userIndex = demoUsers.findIndex((u) => u.id === userId)

        if (userIndex !== -1) {
          // Update the user in demo storage
          demoUsers[userIndex] = { ...demoUsers[userIndex], ...updates, updated_at: new Date().toISOString() }
          saveDemoUsers(demoUsers)

          // Update current demo user
          const updatedAuthUser: AuthUser = {
            id: userId,
            email: demoUsers[userIndex].email,
            profile: demoUsers[userIndex] as UserProfile,
          }
          setCurrentDemoUser(updatedAuthUser)

          return demoUsers[userIndex]
        }
        throw new Error("Utilisateur non trouvé en mode démo")
      }

      // Try Supabase update
      const { data, error } = await supabase
        .from("profiles")
        .update({ ...updates, updated_at: new Date().toISOString() })
        .eq("id", userId)
        .select()
        .single()

      if (error) throw error
      return data
    } catch (error: any) {
      throw new Error(error.message || "Erreur lors de la mise à jour du profil")
    }
  }

  static async checkUsernameAvailable(username: string): Promise<boolean> {
    const { data } = await supabase.from("profiles").select("id").eq("username", username).single()

    return !data
  }

  static async checkPhoneAvailable(phone: string): Promise<boolean> {
    const { data } = await supabase.from("profiles").select("id").eq("phone", phone).single()

    return !data
  }
}
