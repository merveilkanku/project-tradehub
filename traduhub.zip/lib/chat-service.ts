import { supabase } from "./supabase"

export interface Conversation {
  id: string
  participant1_id: string
  participant2_id: string
  product_id?: string
  last_message?: string
  last_message_at?: string
  created_at: string
  participant1: {
    id: string
    full_name: string
    avatar_url: string | null
  }
  participant2: {
    id: string
    full_name: string
    avatar_url: string | null
  }
  product?: {
    id: string
    title: string
    images: string[]
  }
}

export interface Message {
  id: string
  conversation_id: string
  sender_id: string
  content: string
  created_at: string
  sender: {
    id: string
    full_name: string
    avatar_url: string | null
  }
}

export class ChatService {
  static async getConversations(userId: string): Promise<Conversation[]> {
    const { data, error } = await supabase
      .from("conversations")
      .select(`
        *,
        participant1:participant1_id (id, full_name, avatar_url),
        participant2:participant2_id (id, full_name, avatar_url),
        product:product_id (id, title, images)
      `)
      .or(`participant1_id.eq.${userId},participant2_id.eq.${userId}`)
      .order("last_message_at", { ascending: false, nullsFirst: false })

    if (error) throw error
    return data as Conversation[]
  }

  static async getMessages(conversationId: string): Promise<Message[]> {
    const { data, error } = await supabase
      .from("messages")
      .select(`
        *,
        sender:sender_id (id, full_name, avatar_url)
      `)
      .eq("conversation_id", conversationId)
      .order("created_at", { ascending: true })

    if (error) throw error
    return data as Message[]
  }

  static async sendMessage(conversationId: string, senderId: string, content: string): Promise<Message> {
    const { data, error } = await supabase
      .from("messages")
      .insert({
        conversation_id: conversationId,
        sender_id: senderId,
        content: content.trim(),
      })
      .select(`
        *,
        sender:sender_id (id, full_name, avatar_url)
      `)
      .single()

    if (error) throw error

    // Update conversation last message
    await supabase
      .from("conversations")
      .update({
        last_message: content.trim(),
        last_message_at: new Date().toISOString(),
      })
      .eq("id", conversationId)

    return data as Message
  }

  static async startConversation(
    participant1Id: string,
    participant2Id: string,
    productId?: string,
  ): Promise<Conversation> {
    // Check if conversation already exists
    const { data: existing } = await supabase
      .from("conversations")
      .select("id")
      .or(
        `and(participant1_id.eq.${participant1Id},participant2_id.eq.${participant2Id}),and(participant1_id.eq.${participant2Id},participant2_id.eq.${participant1Id})`,
      )
      .maybeSingle()

    if (existing) {
      // Return existing conversation
      const { data, error } = await supabase
        .from("conversations")
        .select(`
          *,
          participant1:participant1_id (id, full_name, avatar_url),
          participant2:participant2_id (id, full_name, avatar_url),
          product:product_id (id, title, images)
        `)
        .eq("id", existing.id)
        .single()

      if (error) throw error
      return data as Conversation
    }

    // Create new conversation
    const { data, error } = await supabase
      .from("conversations")
      .insert({
        participant1_id: participant1Id,
        participant2_id: participant2Id,
        product_id: productId,
      })
      .select(`
        *,
        participant1:participant1_id (id, full_name, avatar_url),
        participant2:participant2_id (id, full_name, avatar_url),
        product:product_id (id, title, images)
      `)
      .single()

    if (error) throw error
    return data as Conversation
  }

  static subscribeToMessages(conversationId: string, callback: (message: Message) => void) {
    return supabase
      .channel(`messages:${conversationId}`)
      .on(
        "postgres_changes",
        {
          event: "INSERT",
          schema: "public",
          table: "messages",
          filter: `conversation_id=eq.${conversationId}`,
        },
        async (payload) => {
          // Fetch the complete message with sender info
          const { data } = await supabase
            .from("messages")
            .select(`
              *,
              sender:sender_id (id, full_name, avatar_url)
            `)
            .eq("id", payload.new.id)
            .single()

          if (data) {
            callback(data as Message)
          }
        },
      )
      .subscribe()
  }
}
