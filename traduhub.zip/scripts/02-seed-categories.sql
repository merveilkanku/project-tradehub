-- Insert default product categories for African marketplace
INSERT INTO categories (name, slug, description, icon) VALUES
('Électronique', 'electronique', 'Téléphones, ordinateurs, accessoires électroniques', '📱'),
('Mode & Vêtements', 'mode-vetements', 'Vêtements, chaussures, accessoires de mode', '👕'),
('Maison & Jardin', 'maison-jardin', 'Meubles, décoration, outils de jardinage', '🏠'),
('Alimentation', 'alimentation', 'Produits alimentaires, boissons, épices', '🍎'),
('Santé & Beauté', 'sante-beaute', 'Cosmétiques, produits de santé, bien-être', '💄'),
('Automobile', 'automobile', 'Pièces auto, accessoires, véhicules', '🚗'),
('Sports & Loisirs', 'sports-loisirs', 'Équipements sportifs, jeux, loisirs', '⚽'),
('Livres & Éducation', 'livres-education', 'Livres, matériel éducatif, fournitures', '📚'),
('Artisanat Local', 'artisanat-local', 'Produits artisanaux, art traditionnel', '🎨'),
('Agriculture', 'agriculture', 'Outils agricoles, semences, équipements', '🌾'),
('Bijoux & Accessoires', 'bijoux-accessoires', 'Bijoux, montres, accessoires précieux', '💍'),
('Enfants & Bébés', 'enfants-bebes', 'Vêtements enfants, jouets, puériculture', '🧸'),
('Immobilier', 'immobilier', 'Locations, ventes, services immobiliers', '🏘️'),
('Services', 'services', 'Services professionnels, réparations', '🔧'),
('Autres', 'autres', 'Produits divers non classés', '📦')
ON CONFLICT (slug) DO NOTHING;
