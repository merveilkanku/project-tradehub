-- Seed initial data for TradHub

-- Insert francophone African countries
INSERT INTO countries (code, name) VALUES
  ('CD', 'République Démocratique du Congo'),
  ('CM', 'Cameroun'),
  ('CI', 'Côte d''Ivoire'),
  ('BF', 'Burkina Faso'),
  ('ML', 'Mali'),
  ('SN', 'Sénégal'),
  ('NE', 'Niger'),
  ('GN', 'Guinée'),
  ('TD', 'Tchad'),
  ('CG', 'République du Congo'),
  ('RW', 'Rwanda'),
  ('BI', 'Burundi'),
  ('CF', 'République Centrafricaine'),
  ('GA', 'Gabon'),
  ('KM', 'Comores'),
  ('DJ', 'Djibouti'),
  ('MG', 'Madagascar'),
  ('SC', 'Seychelles'),
  ('BJ', 'Bénin'),
  ('TG', 'Togo')
ON CONFLICT (code) DO NOTHING;

-- Insert cities for major countries
INSERT INTO cities (country_id, name) 
SELECT c.id, city_name FROM countries c
CROSS JOIN (VALUES 
  ('CD', 'Kinshasa'),
  ('CD', 'Lubumbashi'),
  ('CD', 'Mbuji-Mayi'),
  ('CD', 'Kisangani'),
  ('CM', 'Yaoundé'),
  ('CM', 'Douala'),
  ('CM', 'Bamenda'),
  ('CM', 'Bafoussam'),
  ('CI', 'Abidjan'),
  ('CI', 'Yamoussoukro'),
  ('CI', 'Bouaké'),
  ('CI', 'Daloa'),
  ('BF', 'Ouagadougou'),
  ('BF', 'Bobo-Dioulasso'),
  ('ML', 'Bamako'),
  ('ML', 'Sikasso'),
  ('SN', 'Dakar'),
  ('SN', 'Thiès'),
  ('SN', 'Kaolack'),
  ('NE', 'Niamey'),
  ('NE', 'Zinder'),
  ('GN', 'Conakry'),
  ('GN', 'Nzérékoré'),
  ('TD', 'N''Djamena'),
  ('TD', 'Moundou'),
  ('CG', 'Brazzaville'),
  ('CG', 'Pointe-Noire')
) AS city_data(country_code, city_name)
WHERE c.code = city_data.country_code
ON CONFLICT DO NOTHING;

-- Insert product categories
INSERT INTO categories (name, description, icon) VALUES
  ('Électronique', 'Smartphones, ordinateurs, accessoires tech', 'Smartphone'),
  ('Mode & Beauté', 'Vêtements, chaussures, cosmétiques', 'Shirt'),
  ('Maison & Jardin', 'Meubles, décoration, outils de jardinage', 'Home'),
  ('Alimentation', 'Produits alimentaires, boissons', 'UtensilsCrossed'),
  ('Santé & Bien-être', 'Médicaments, compléments, équipements médicaux', 'Heart'),
  ('Sport & Loisirs', 'Équipements sportifs, jeux, loisirs', 'Dumbbell'),
  ('Automobile', 'Pièces auto, accessoires, véhicules', 'Car'),
  ('Éducation', 'Livres, fournitures scolaires, cours', 'BookOpen'),
  ('Services', 'Services professionnels, réparations', 'Wrench'),
  ('Artisanat', 'Produits artisanaux, art local', 'Palette')
ON CONFLICT DO NOTHING;
