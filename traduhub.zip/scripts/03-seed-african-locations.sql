-- Insert African francophone countries and major cities
-- This will help with location-based filtering and search

-- Note: This is a simplified list focusing on major francophone African countries and cities
-- In a real application, you might want to use a more comprehensive location database

CREATE TABLE IF NOT EXISTS countries (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  code TEXT UNIQUE NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS cities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  country_code TEXT NOT NULL REFERENCES countries(code),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Insert francophone African countries
INSERT INTO countries (name, code) VALUES
('République Démocratique du Congo', 'CD'),
('Cameroun', 'CM'),
('Côte d''Ivoire', 'CI'),
('Burkina Faso', 'BF'),
('Mali', 'ML'),
('Niger', 'NE'),
('Sénégal', 'SN'),
('Tchad', 'TD'),
('Guinée', 'GN'),
('Rwanda', 'RW'),
('Burundi', 'BI'),
('Togo', 'TG'),
('Bénin', 'BJ'),
('République Centrafricaine', 'CF'),
('Congo-Brazzaville', 'CG'),
('Gabon', 'GA'),
('Djibouti', 'DJ'),
('Comores', 'KM'),
('Madagascar', 'MG'),
('Maurice', 'MU')
ON CONFLICT (code) DO NOTHING;

-- Insert major cities for each country
INSERT INTO cities (name, country_code) VALUES
-- RDC
('Kinshasa', 'CD'),
('Lubumbashi', 'CD'),
('Mbuji-Mayi', 'CD'),
('Kisangani', 'CD'),
('Bukavu', 'CD'),
('Goma', 'CD'),
-- Cameroun
('Yaoundé', 'CM'),
('Douala', 'CM'),
('Bamenda', 'CM'),
('Bafoussam', 'CM'),
('Garoua', 'CM'),
-- Côte d'Ivoire
('Abidjan', 'CI'),
('Yamoussoukro', 'CI'),
('Bouaké', 'CI'),
('Daloa', 'CI'),
('San-Pédro', 'CI'),
-- Burkina Faso
('Ouagadougou', 'BF'),
('Bobo-Dioulasso', 'BF'),
('Koudougou', 'BF'),
-- Mali
('Bamako', 'ML'),
('Sikasso', 'ML'),
('Mopti', 'ML'),
('Ségou', 'ML'),
-- Niger
('Niamey', 'NE'),
('Zinder', 'NE'),
('Maradi', 'NE'),
-- Sénégal
('Dakar', 'SN'),
('Thiès', 'SN'),
('Kaolack', 'SN'),
('Saint-Louis', 'SN'),
-- Tchad
('N''Djamena', 'TD'),
('Moundou', 'TD'),
('Sarh', 'TD'),
-- Guinée
('Conakry', 'GN'),
('Nzérékoré', 'GN'),
('Kankan', 'GN'),
-- Rwanda
('Kigali', 'RW'),
('Butare', 'RW'),
('Gitarama', 'RW'),
-- Burundi
('Bujumbura', 'BI'),
('Gitega', 'BI'),
-- Togo
('Lomé', 'TG'),
('Sokodé', 'TG'),
-- Bénin
('Cotonou', 'BJ'),
('Porto-Novo', 'BJ'),
('Parakou', 'BJ'),
-- République Centrafricaine
('Bangui', 'CF'),
-- Congo-Brazzaville
('Brazzaville', 'CG'),
('Pointe-Noire', 'CG'),
-- Gabon
('Libreville', 'GA'),
('Port-Gentil', 'GA'),
-- Djibouti
('Djibouti', 'DJ'),
-- Comores
('Moroni', 'KM'),
-- Madagascar
('Antananarivo', 'MG'),
('Toamasina', 'MG'),
('Antsirabe', 'MG'),
-- Maurice
('Port-Louis', 'MU'),
('Beau-Bassin', 'MU')
ON CONFLICT DO NOTHING;

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_cities_country_code ON cities(country_code);
