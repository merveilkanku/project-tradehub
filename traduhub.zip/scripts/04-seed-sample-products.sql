-- Insert sample products for testing (optional)
-- This script adds some sample products to help test the product management system

-- First, let's create a sample supplier profile (you can skip this if you have real suppliers)
INSERT INTO profiles (
  id,
  user_type,
  email,
  phone,
  username,
  full_name,
  bio,
  country,
  city,
  address,
  payment_status,
  is_verified
) VALUES (
  '550e8400-e29b-41d4-a716-446655440000',
  'supplier',
  'supplier@example.com',
  '+243123456789',
  'supplier_demo',
  'Fournisseur Démo',
  'Fournisseur de produits électroniques et accessoires',
  'CD',
  'Kinshasa',
  '123 Avenue de la Paix',
  'paid',
  true
) ON CONFLICT (id) DO NOTHING;

-- Insert sample products
INSERT INTO products (
  supplier_id,
  title,
  description,
  price,
  currency,
  category,
  images,
  stock_quantity,
  is_active,
  country,
  city
) VALUES 
(
  '550e8400-e29b-41d4-a716-446655440000',
  'Smartphone Samsung Galaxy A54',
  'Smartphone Android avec écran AMOLED 6.4", 128GB de stockage, appareil photo 50MP. Parfait état, garantie 1 an.',
  450.00,
  'USD',
  'Électronique',
  ARRAY['/placeholder.svg?height=400&width=400'],
  15,
  true,
  'CD',
  'Kinshasa'
),
(
  '550e8400-e29b-41d4-a716-446655440000',
  'Ordinateur Portable HP Pavilion',
  'Laptop HP avec processeur Intel i5, 8GB RAM, 256GB SSD. Idéal pour le travail et les études.',
  650.00,
  'USD',
  'Électronique',
  ARRAY['/placeholder.svg?height=400&width=400'],
  8,
  true,
  'CD',
  'Kinshasa'
),
(
  '550e8400-e29b-41d4-a716-446655440000',
  'Robe Africaine Traditionnelle',
  'Belle robe en tissu wax authentique, taille M. Parfaite pour les occasions spéciales.',
  85.00,
  'USD',
  'Mode & Vêtements',
  ARRAY['/placeholder.svg?height=400&width=400'],
  25,
  true,
  'CD',
  'Kinshasa'
),
(
  '550e8400-e29b-41d4-a716-446655440000',
  'Café Arabica Premium',
  'Café arabica de haute qualité cultivé localement. Torréfaction artisanale, arôme exceptionnel.',
  25.00,
  'USD',
  'Alimentation',
  ARRAY['/placeholder.svg?height=400&width=400'],
  50,
  true,
  'CD',
  'Kinshasa'
),
(
  '550e8400-e29b-41d4-a716-446655440000',
  'Sculpture en Bois Artisanale',
  'Sculpture traditionnelle en bois d\'ébène, réalisée par des artisans locaux. Pièce unique.',
  120.00,
  'USD',
  'Artisanat Local',
  ARRAY['/placeholder.svg?height=400&width=400'],
  3,
  false,
  'CD',
  'Kinshasa'
) ON CONFLICT DO NOTHING;
